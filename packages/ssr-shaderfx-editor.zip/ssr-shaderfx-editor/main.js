'use strict';

module.exports = {
    load() {
    },
    unload() {
    },
    messages: {
        'open' () {
            Editor.Panel.open('ssr-shaderfx-editor');
        },
    },
};
